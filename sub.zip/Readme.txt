heroku: https://dnddmilestone3.herokuapp.com/

git: https://github.com/djl1005/DnDD/

purpuse: to allow users to create custom monsters for pathfinder.

MVC: MVC was used to handle the sites layout with the views being the handlebars files the controler being the server code and the model being the DB.

Mongo: was used for storing user acounts and monster data, both were retrived but monster data can be deleted. 

Template : handlebars  was used for the template, but I added helpers small custom functions that the template can call well being created